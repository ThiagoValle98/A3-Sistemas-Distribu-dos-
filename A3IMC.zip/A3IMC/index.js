import express from 'express';

import pool from "./pool.js";
import routePerfil from './routes/perfil.js';
import routeHistoricoIMC from './routes/historico_imc.js';
import routeDieta from './routes/dieta.js';
import routeDietaDetalhe from './routes/dieta_detalhe.js';
import routeAlimento from './routes/alimento.js';

const app = express();
app.use(express.json());
app.use(routePerfil);
app.use(routeHistoricoIMC);
app.use(routeDieta);
app.use(routeDietaDetalhe);
app.use(routeAlimento);

const port = 3000;

app.listen(port, () => {
    console.log("Servidor escutando na porta: ", port);
});