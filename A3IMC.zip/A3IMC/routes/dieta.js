import express from 'express';
import pool from '../pool.js';

const routes = express.Router();

routes.get("/dieta/:id_perfil",(req, res, error) =>{
    const sql = 'SELECT * FROM dieta WHERE id_perfil= ' + req.params.id_perfil;
    pool.query(sql, (error, results, fields)=>{
        mensagemDieta(error, results,res);
    });
});

routes.post("/dieta", (req, res, error) =>{
    const sql = 'INSERT INTO dieta(id_perfil, nome) VALUES (?,?)';
    const { id_perfil, nome} = req.body;
    pool.query(sql, [id_perfil, nome], (error, results, fields)=>{
        mensagemDieta(error, results,res);
    });
});

routes.put("/dieta", (req, res, error) =>{
    const sql  = 'UPDATE dieta SET id_perfil=?, nome=? WHERE id =?';
    const {id_perfil, nome, id} = req.body;
    pool.query(sql, [id_perfil, nome, id], (error, results, fields)=>{
        mensagemDieta(error, results,res);
    });
});

routes.delete("/dieta/:id_perfil", (req, res, error)=>{
    const sql = "DELETE FROM dieta WHERE id=?";
    const id = req.params.id_perfil;
    pool.query(sql, [id], (error, results, fields)=>{
        mensagemDieta(error, results,res);
    });
});

function mensagemDieta(error, results,res){
    if (!error){ 
        if(results.length <= 0 ){
            res.status(404).json({msg: "Sem Dieta para exibir"});
        } else {
            res.status(200).json(results);
        }  
    } else {
        res.status(404).json({msg: "Erro não especificado"});
    }
}

export default routes;