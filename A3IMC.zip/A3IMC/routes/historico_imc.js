import express from 'express';
import pool from '../pool.js';

const routes = express.Router();

routes.get("/imc/:id_perfil",(req, res, error) =>{
    const sql = 'SELECT * FROM historico_imc WHERE id_perfil= ' + req.params.id_perfil;
    pool.query(sql, (error, results, fields)=>{
        mensagemHistoricoIMC(error, results,res);
    });
});

routes.post("/imc", (req, res, error) =>{
    const sql = 'INSERT INTO historico_imc(id_perfil, peso, altura) VALUES (?,?,?)';
    const { id_perfil, peso, altura} = req.body;
    pool.query(sql, [id_perfil, peso, altura], (error, results, fields)=>{
        mensagemHistoricoIMC(error, results,res);
    });
});

function mensagemHistoricoIMC(error, results,res){
    if (!error){ 
        if(results.length <= 0 ){
            res.status(404).json({msg: "Sem histórico para exibir"});
        } else {
            res.status(200).json(results);
        }  
    } else {
        res.status(404).json({msg: "Erro não especificado"});
    }
}

export default routes;