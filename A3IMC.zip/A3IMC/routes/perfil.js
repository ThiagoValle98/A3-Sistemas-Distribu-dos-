import express from 'express';
import pool from '../pool.js';

const routes = express.Router();

routes.get("/perfil", (req,res,error) =>{
    const sql = 'SELECT * FROM perfil';
    pool.query(sql, (error, results, fields )=>{
        mensagemPerfil(error, results,res);
    });
});

routes.get("/perfil/:id",(req, res, error) =>{
    const sql = 'SELECT * FROM perfil WHERE id= ' + req.params.id;
    pool.query(sql, (error, results, fields)=>{
        mensagemPerfil(error, results,res);
    });
});

routes.post("/perfil", (req, res, error) =>{
    const sql = 'INSERT INTO perfil(nome, idade, sexo, email, telefone) VALUES (?,?,?,?,?)';
    const { nome, idade, sexo, email, telefone} = req.body;
    pool.query(sql, [nome, idade, sexo, email, telefone], (error, results, fields)=>{
        mensagemPerfil(error, results,res);
    });
});

routes.put("/perfil", (req, res, error) =>{
    const sql  = 'UPDATE perfil SET nome=?, idade=?, sexo=?, email=?, telefone=? WHERE id =?';
    const {nome, idade, sexo, email, telefone,id} = req.body;
    pool.query(sql, [nome, idade, sexo, email,telefone, id], (error, results, fields)=>{
        mensagemPerfil(error, results,res);
    });
});

routes.delete("/perfil/:id", (req, res, error)=>{
    const sql = "DELETE FROM perfil WHERE id=?";
    const id = req.params.id;
    pool.query(sql, [id], (error, results, fields)=>{
        mensagemPerfil(error, results,res);
    });
});

function mensagemPerfil(error, results,res){
    if (!error){ 
        if(results.length <= 0 ){
            res.status(404).json({msg: "Sem Perfil para exibir"});
        } else {
            res.status(200).json(results);
        }  
    } else {
        res.status(404).json({msg: "Erro não especificado"});
    }
}

export default routes;