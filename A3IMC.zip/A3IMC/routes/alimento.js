import express from 'express';
import pool from '../pool.js';

const routes = express.Router();

routes.get("/alimento", (req,res,error) =>{
    const sql = 'SELECT * FROM alimento';
    pool.query(sql, (error, results, fields )=>{
        mensagemAlimento(error, results,res);
    });
});

routes.get("/alimento/:descricao",(req, res, error) =>{
    const sql = 'SELECT * FROM alimento WHERE descricao LIKE "%' + req.params.descricao + '%"';
    pool.query(sql, (error, results, fields)=>{
        mensagemAlimento(error, results,res);
    });
});

routes.post("/alimento", (req, res, error) =>{
    const sql = 'INSERT INTO alimento(descricao, quantidade, calorias) VALUES (?,?,?)';
    const { descricao, quantidade, calorias} = req.body;
    pool.query(sql, [descricao, quantidade, calorias], (error, results, fields)=>{
        mensagemAlimento(error, results,res);
    });
});

routes.put("/alimento", (req, res, error) =>{
    const sql  = 'UPDATE alimento SET descricao=?, quantidade=?, calorias=? WHERE id =?';
    const {descricao, quantidade, calorias,id} = req.body;
    pool.query(sql, [descricao, quantidade, calorias, id], (error, results, fields)=>{
        mensagemAlimento(error, results,res);
    });
});

routes.delete("/alimento/:id", (req, res, error)=>{
    const sql = "DELETE FROM alimento WHERE id=?";
    const id = req.params.id;
    pool.query(sql, [id], (error, results, fields)=>{
        mensagemAlimento(error, results,res);
    });
});

function mensagemAlimento(error, results,res){
    if (!error){ 
        if(results.length <= 0 ){
            res.status(404).json({msg: "Sem Alimento para exibir"});
        } else {
            res.status(200).json(results);
        }  
    } else {
        res.status(404).json({msg: "Erro não especificado"});
    }
}

export default routes;