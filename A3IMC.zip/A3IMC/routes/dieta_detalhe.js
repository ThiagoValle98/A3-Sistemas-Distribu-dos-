import express from 'express';
import pool from '../pool.js';

const routes = express.Router();

routes.get("/dieta_detalhe", (req,res,error) =>{
    const sql = 'SELECT * FROM dieta_detalhe';
    pool.query(sql, (error, results, fields )=>{
        mensagemDietaDetalhe(error, results,res);
    });
});

routes.get("/dieta_detalhe/:id_dieta",(req, res, error) =>{
    const sql = 'SELECT * FROM dieta_detalhe WHERE id_dieta= ' + req.params.id_dieta;
    pool.query(sql, (error, results, fields)=>{
        mensagemDietaDetalhe(error, results,res);
    });
});

routes.post("/dieta_detalhe", (req, res, error) =>{
    const sql = 'INSERT INTO dieta_detalhe(id_dieta, id_alimento, quantidade) VALUES (?,?,?)';
    const { id_dieta, id_alimento, quantidade} = req.body;
    pool.query(sql, [id_dieta, id_alimento, quantidade], (error, results, fields)=>{
        mensagemDietaDetalhe(error, results,res);
    });
});

routes.put("/dieta_detalhe", (req, res, error) =>{
    const sql  = 'UPDATE dieta_detalhe SET id_alimento=?, quantidade=? WHERE id =?';
    const {id_alimento, quantidade, id} = req.body;
    pool.query(sql, [id_alimento, quantidade, id], (error, results, fields)=>{
        mensagemDietaDetalhe(error, results,res);
    });
});

routes.delete("/dieta_detalhe/:id", (req, res, error)=>{
    const sql = "DELETE FROM dieta_detalhe WHERE id=?";
    const id = req.params.id;
    pool.query(sql, [id], (error, results, fields)=>{
        mensagemDietaDetalhe(error, results,res);
    });
});

function mensagemDietaDetalhe(error, results,res){
    if (!error){ 
        if(results.length <= 0 ){
            res.status(404).json({msg: "Sem Detalhe para esta Dieta"});
        } else {
            res.status(200).json(results);
        }  
    } else {
        res.status(404).json({msg: "Erro não especificado"});
    }
}

export default routes;